jQuery(document).ready(function ($) {
  // Initialize YouTube API if not already loaded
  if (typeof YT === "undefined") {
    var tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName("script")[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
  }

  window.elementorYoutubeFormPlayers = window.elementorYoutubeFormPlayers || {};

  // Global YouTube API ready function
  window.onYouTubeIframeAPIReady = function () {
    $(".youtube-form-container").each(function () {
      initYoutubeFormWidget($(this));
    });
  };

  function initYoutubeFormWidget(container) {
    var videoId = container.data("video-id");
    var pauseTime = parseFloat(container.data("pause-time"));
    var widgetId = container.data("widget-id");
    var videoTitle = container.data("video-title");
    var autoplay = container.data("autoplay") === "yes";
    var muteOnAutoplay = container.data("mute-on-autoplay") === "yes";
    var iframeId = "youtube-video-" + widgetId;
    var popupId = "form-popup-" + widgetId;
    var formId = "youtube-form-" + widgetId;

    var player;
    var timeInterval;
    var pauseTimePosition;
    var formSubmitted = false;

    // Disable right-click on the video container
    container.on("contextmenu", function (e) {
      e.preventDefault();
      return false;
    });

    // Also disable right-click on the iframe
    var iframe = document.getElementById(iframeId);
    if (iframe) {
      iframe.addEventListener("load", function () {
        try {
          iframe.contentWindow.document.addEventListener(
            "contextmenu",
            function (e) {
              e.preventDefault();
              return false;
            }
          );
        } catch (e) {
          console.log("Could not disable right-click in iframe:", e);
        }
      });
    }

    // Create custom controls container with title bar
    container.append(`
            <div class="custom-title-bar">
                <div class="video-title">${videoTitle}</div>
            </div>
            <div class="custom-video-controls">
                <button class="play-btn" title="Play/Pause">▶</button>
                <div class="progress-container">
                    <div class="progress-bar"></div>
                </div>
                <span class="time-display">0:00 / 0:00</span>
                <button class="mute-btn" title="Mute/Unmute">🔊</button>
                <input type="range" class="volume-slider" min="0" max="100" value="100">
                <button class="fullscreen-btn" title="Fullscreen">⛶</button>
            </div>
        `);

    // Initialize player with proper autoplay handling
    function initializePlayer() {
      if (typeof YT !== "undefined" && YT.Player) {
        createPlayer();
      } else {
        // If YT is not defined, wait for the API to load
        var checkReady = setInterval(function () {
          if (typeof YT !== "undefined" && YT.Player) {
            clearInterval(checkReady);
            createPlayer();
          }
        }, 100);
      }
    }

    function createPlayer() {
      // Player parameters that work with browser autoplay policies
      var playerVars = {
        controls: 0,
        modestbranding: 1,
        disablekb: 1,
        rel: 0,
        showinfo: 0,
        enablejsapi: 1,
      };

      // Apply autoplay settings according to browser policies

      if (autoplay) {
        container.find(".youtube-video-overlay").addClass("autoplay-active");

        // Remove overlay when user interacts with controls
        container
          .find(".custom-video-controls, .custom-title-bar")
          .on("click", function () {
            container
              .find(".youtube-video-overlay")
              .removeClass("autoplay-active");
            container.find("iframe").css("pointer-events", "auto");
          });
      }

      player = new YT.Player(iframeId, {
        events: {
          onReady: onPlayerReady,
          onStateChange: onPlayerStateChange,
        },
        playerVars: playerVars,
      });

      window.elementorYoutubeFormPlayers[iframeId] = player;
    }

    function onPlayerReady(event) {
      // Hide all native YouTube controls
      var css = `
                .ytp-chrome-top, .ytp-chrome-bottom,
                .ytp-watermark, .ytp-show-cards-title,
                .ytp-impression-link, .ytp-pause-overlay,
                .ytp-youtube-button, .ytp-button,
                .ytp-progress-bar-container {
                    display: none !important;
                }
                
                /* Make specific elements transparent */
                .ytp-youtube-button.ytp-button.yt-uix-sessionlink,
                .ytp-impression-link-content {
                    opacity: 0 !important;
                    pointer-events: none !important;
                    visibility: hidden !important;
                }
            `;

      try {
        var iframe = $("#" + iframeId)[0];
        var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        if (iframeDoc) {
          var style = document.createElement("style");
          style.type = "text/css";
          style.appendChild(document.createTextNode(css));
          iframeDoc.head.appendChild(style);
        }
      } catch (e) {
        console.log("Error hiding native controls:", e);
      }

      // Setup custom controls
      setupCustomControls();

      // Handle autoplay with browser policy compliance
      if (autoplay) {
        // Some browsers may still block autoplay, so we need to handle this case
        setTimeout(function () {
          if (player.getPlayerState() !== YT.PlayerState.PLAYING) {
            // Try to play with mute if not already playing
            if (muteOnAutoplay) {
              player.mute();
            }
            player.playVideo().catch((error) => {
              console.log("Autoplay was prevented:", error);
              // Show play button if autoplay fails
              container.find(".play-btn").text("▶");
            });
          }
          container.find(".play-btn").text("❚❚");
        }, 1000);
      }
    }

    function setupCustomControls() {
      var controls = container.find(".custom-video-controls");
      var playBtn = controls.find(".play-btn");
      var progressBar = controls.find(".progress-bar");
      var timeDisplay = controls.find(".time-display");
      var muteBtn = controls.find(".mute-btn");
      var volumeSlider = controls.find(".volume-slider");
      var fullscreenBtn = controls.find(".fullscreen-btn");
      var videoWrapper = container.find(".youtube-video-wrapper");
      var videoOverlay = container.find(".youtube-video-overlay");

      // Make overlay interactive when controls are hovered
      controls
        .on("mouseenter", function () {
          videoOverlay.addClass("active");
        })
        .on("mouseleave", function () {
          videoOverlay.removeClass("active");
        });

      // Add click handler for the overlay
      videoOverlay.on("click", function () {
        if (player.getPlayerState() === YT.PlayerState.PLAYING) {
          player.pauseVideo();
          playBtn.text("▶");
        } else {
          player.playVideo();
          playBtn.text("❚❚");
        }
      });

      // Update time display
      function updateTimeDisplay() {
        var currentTime = player.getCurrentTime();
        var duration = player.getDuration();

        function formatTime(seconds) {
          var minutes = Math.floor(seconds / 60);
          var secs = Math.floor(seconds % 60);
          return minutes + ":" + (secs < 10 ? "0" : "") + secs;
        }

        var progressPercent = (currentTime / duration) * 100;
        progressBar.css("width", progressPercent + "%");
        timeDisplay.text(
          formatTime(currentTime) + " / " + formatTime(duration)
        );
      }

      // Play/Pause button
      playBtn.on("click", function () {
        if (player.getPlayerState() === YT.PlayerState.PLAYING) {
          player.pauseVideo();
          playBtn.text("▶");
        } else {
          player.playVideo();
          playBtn.text("❚❚");
        }
      });

      // Progress bar click
      container.find(".progress-container").on("click", function (e) {
        var offset = e.pageX - $(this).offset().left;
        var width = $(this).width();
        player.seekTo(player.getDuration() * (offset / width));
      });

      // In the setupCustomControls function, update the mute button section:
      muteBtn.on("click", function () {
        if (player.isMuted()) {
          player.unMute();
          muteBtn.text("🔊");
          muteBtn.removeClass("muted-active"); // Remove red color class
          volumeSlider.val(player.getVolume());
        } else {
          player.mute();
          muteBtn.text("🔇");
          muteBtn.addClass("muted-active"); // Add red color class
          volumeSlider.val(0);
        }
      });

      // Also update the volume slider section to handle the mute state:
      volumeSlider.on("input", function () {
        player.setVolume($(this).val());
        if ($(this).val() == 0) {
          player.mute();
          muteBtn.text("🔇");
          muteBtn.addClass("muted-active");
        } else {
          player.unMute();
          muteBtn.text("🔊");
          muteBtn.removeClass("muted-active");
        }
      });

      // Initialize mute state if autoplay with mute is enabled
      if (autoplay && muteOnAutoplay) {
        muteBtn.text("🔇");
        muteBtn.addClass("muted-active"); // Add red color class initially
      }

      // Volume slider
      volumeSlider.on("input", function () {
        player.setVolume($(this).val());
        if ($(this).val() == 0) {
          player.mute();
          muteBtn.text("🔇");
        } else {
          player.unMute();
          muteBtn.text("🔊");
        }
      });

      // Fullscreen button
      fullscreenBtn.on("click", function () {
        var container = $(this).closest(".youtube-form-container");
        var iframe = container.find("iframe")[0];

        if (!document.fullscreenElement) {
          // Enter fullscreen
          if (container[0].requestFullscreen) {
            container[0].requestFullscreen();
          } else if (container[0].webkitRequestFullscreen) {
            container[0].webkitRequestFullscreen();
          } else if (container[0].msRequestFullscreen) {
            container[0].msRequestFullscreen();
          }

          // Adjust styles for fullscreen
          container.addClass("fullscreen-active");
          $("body").addClass("fullscreen-video-active");
        } else {
          // Exit fullscreen
          if (document.exitFullscreen) {
            document.exitFullscreen();
          } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
          } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
          }
        }
      });

      // Handle fullscreen change events
      document.addEventListener("fullscreenchange", handleFullscreenChange);
      document.addEventListener(
        "webkitfullscreenchange",
        handleFullscreenChange
      );
      document.addEventListener("msfullscreenchange", handleFullscreenChange);

      function handleFullscreenChange() {
        var container = $(".youtube-form-container");
        if (
          !document.fullscreenElement &&
          !document.webkitFullscreenElement &&
          !document.msFullscreenElement
        ) {
          // Exited fullscreen
          container.removeClass("fullscreen-active");
          $("body").removeClass("fullscreen-video-active");
        }
      }

      // Update controls every 500ms
      setInterval(updateTimeDisplay, 500);
    }

    function onPlayerStateChange(event) {
      if (event.data == YT.PlayerState.PLAYING && !formSubmitted) {
        if (timeInterval) clearInterval(timeInterval);
        timeInterval = setInterval(function () {
          var currentTime = player.getCurrentTime();
          if (currentTime >= pauseTime) {
            clearInterval(timeInterval);
            pauseTimePosition = currentTime;
            handlePauseEvent();
          }
        }, 500);
      } else if (event.data == YT.PlayerState.PAUSED) {
        if (timeInterval) clearInterval(timeInterval);
      }
    }

    function handlePauseEvent() {
      player.pauseVideo();
      showPopup();

      $("#" + formId)
        .off("submit")
        .on("submit", function (e) {
          e.preventDefault();
          var $form = $(this);
          var $message = $form.siblings(".form-message");

          $form.find(".form-group").removeClass("has-error");
          $form.find(".error-message").remove();
          $message.hide().removeClass("success error").empty();

          var $submitBtn = $form.find(".submit-btn");
          var originalBtnText = $submitBtn.html();
          $submitBtn
            .html(
              '<span class="btn-loader"></span> ' +
                elementorYoutubeForm.loadingText
            )
            .prop("disabled", true);

          var formData = {};
          $form.find("input, textarea, select").each(function () {
            var $field = $(this);
            var fieldName = $field.attr("name");
            var fieldType = $field.attr("type");

            if (fieldType === "submit" || fieldType === "button") return;

            if (fieldType === "checkbox") {
              formData[fieldName] = $field.is(":checked") ? $field.val() : "";
            } else if (fieldType === "radio") {
              if ($field.is(":checked")) {
                formData[fieldName] = $field.val();
              }
            } else {
              formData[fieldName] = $field.val();
            }
          });

          formData.post_id = $form.find('input[name="post_id"]').val();
          formData.widget_id = $form.find('input[name="widget_id"]').val();

          $.ajax({
            url: elementorYoutubeForm.ajaxurl,
            type: "POST",
            dataType: "json",
            data: {
              action: "elementor_youtube_form_submit",
              form_data: formData,
              nonce: elementorYoutubeForm.nonce,
            },
            success: function (response) {
              if (response.success) {
                $message.html(response.data.message).addClass("success").show();
                $form.hide();

                setTimeout(function () {
                  closePopup();
                  formSubmitted = true;
                  player.playVideo();
                }, 3000);
              } else {
                var errorMsg =
                  response.data.message || elementorYoutubeForm.errorText;
                $message.html(errorMsg).addClass("error").show();
                $submitBtn.html(originalBtnText).prop("disabled", false);

                $form.addClass("shake");
                setTimeout(function () {
                  $form.removeClass("shake");
                }, 500);
              }
            },
            error: function (xhr, status, error) {
              console.error("Submission error:", error, xhr.responseText);
              $message
                .html(elementorYoutubeForm.errorText)
                .addClass("error")
                .show();
              $submitBtn.html(originalBtnText).prop("disabled", false);

              $form.addClass("shake");
              setTimeout(function () {
                $form.removeClass("shake");
              }, 500);
            },
          });
        });
    }

    function showPopup() {
      $("#" + popupId).fadeIn();
      $(".youtube-form-container").css("overflow", "hidden");
      $("#" + popupId)
        .find("input, textarea, select")
        .first()
        .focus();

      $("#" + popupId)
        .find(".popup-overlay, .close-popup")
        .on("click", function (e) {
          e.preventDefault();
          closePopup();
        });
    }

    function closePopup() {
      $("#" + popupId).fadeOut(function () {
        player.seekTo(pauseTimePosition);
        player.playVideo();
        $(".youtube-form-container").css("overflow", "");
      });
    }

    // Initialize the player
    initializePlayer();
  }

  // Initialize when API is ready
  if (typeof YT !== "undefined" && YT.loaded) {
    window.onYouTubeIframeAPIReady();
  }

  // Initialize widgets added via AJAX
  $(document).on("elementor/popup/show", function () {
    $(".youtube-form-container").each(function () {
      if (!$(this).data("initialized")) {
        initYoutubeFormWidget($(this));
        $(this).data("initialized", true);
      }
    });
  });

  // Handle ESC key to exit fullscreen
  $(document).on("keydown", function (e) {
    if (
      e.key === "Escape" &&
      $(".youtube-form-container").hasClass("fullscreen-active")
    ) {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
    }
  });
});
