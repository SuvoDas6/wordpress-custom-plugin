<?php
/**
 * Plugin Name: Elementor YouTube Form Addon (Enhanced)
 * Description: Embed YouTube videos with pause-triggered form popups that save to database + Webhook support
 * Version: 1.5.0
 * Author: Biman Kumar Dash
 * Author URI: https://web.facebook.com/Wordpressdeveloperdesign
 * Plugin URI: https://github.com/bimandash/Elementor-YouTube-Form-Addon-Enhanced-.git
 * Text Domain: elementor-youtube-form
 */

if (!defined('ABSPATH')) {
    exit;
}

// ==================== DATABASE SETUP ====================
register_activation_hook(__FILE__, 'elementor_youtube_form_create_db_table');

function elementor_youtube_form_create_db_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'elementor_youtube_form_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        post_id mediumint(9) NOT NULL,
        widget_id varchar(100) NOT NULL,
        video_id varchar(20) NOT NULL,
        form_data longtext NOT NULL,
        submitted_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        webhook_response longtext NULL,
        webhook_status varchar(20) NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// ==================== ADMIN INTERFACE ====================
add_action('admin_menu', 'elementor_youtube_form_add_admin_menu');

function elementor_youtube_form_add_admin_menu() {
    add_menu_page(
        __('Video Form Submissions', 'elementor-youtube-form'),
        __('Video Form Data', 'elementor-youtube-form'),
        'manage_options',
        'youtube-form-submissions',
        'elementor_youtube_form_submissions_page',
        'dashicons-video-alt3',
        30
    );
}

function elementor_youtube_form_submissions_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'elementor_youtube_form_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    
    ?>
    <div class="wrap">
        <h1><?php _e('Video Form Submissions', 'elementor-youtube-form'); ?></h1>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Post</th>
                    <th>Video ID</th>
                    <th>Form Data</th>
                    <th>Webhook Status</th>
                    <th>Response</th>
                    <th>Submitted At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($submissions as $submission): 
                    $post_title = get_the_title($submission->post_id);
                    $post_link = get_edit_post_link($submission->post_id);
                ?>
                <tr>
                    <td><?php echo $submission->id; ?></td>
                    <td>
                        <?php if ($post_link): ?>
                            <a href="<?php echo esc_url($post_link); ?>"><?php echo esc_html($post_title); ?></a>
                        <?php else: ?>
                            <?php echo esc_html($post_title); ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="https://youtu.be/<?php echo esc_attr($submission->video_id); ?>" target="_blank">
                            <?php echo esc_html($submission->video_id); ?>
                        </a>
                    </td>
                    <td>
                        <?php 
                        $form_data = maybe_unserialize($submission->form_data);
                        if (is_array($form_data)) {
                            echo '<ul style="margin:0;padding-left:20px;">';
                            foreach ($form_data as $key => $value) {
                                if (is_array($value)) {
                                    $value = implode(', ', $value);
                                }
                                echo '<li><strong>' . esc_html($key) . ':</strong> ' . esc_html($value) . '</li>';
                            }
                            echo '</ul>';
                        }
                        ?>
                    </td>
                    <td><?php echo esc_html($submission->webhook_status ?? 'Not sent'); ?></td>
                    <td>
                        <?php if (!empty($submission->webhook_response)): ?>
                            <details>
                                <summary>View Response</summary>
                                <pre><?php echo esc_html($submission->webhook_response); ?></pre>
                            </details>
                        <?php endif; ?>
                    </td>
                    <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($submission->submitted_at)); ?></td>
                    <td>
                        <a href="#" class="button button-small delete-submission" data-id="<?php echo $submission->id; ?>">
                            <?php _e('Delete', 'elementor-youtube-form'); ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('.delete-submission').on('click', function(e) {
            e.preventDefault();
            var $button = $(this);
            var submissionId = $button.data('id');
            
            if (confirm('<?php _e('Are you sure you want to delete this submission?', 'elementor-youtube-form'); ?>')) {
                $button.text('<?php _e('Deleting...', 'elementor-youtube-form'); ?>').prop('disabled', true);
                
                $.post(ajaxurl, {
                    action: 'elementor_youtube_form_delete_submission',
                    id: submissionId,
                    nonce: '<?php echo wp_create_nonce('elementor_youtube_form_delete_nonce'); ?>'
                }, function(response) {
                    if (response.success) {
                        $button.closest('tr').fadeOut(function() {
                            $(this).remove();
                        });
                    } else {
                        alert('<?php _e('Error deleting submission', 'elementor-youtube-form'); ?>');
                        $button.text('<?php _e('Delete', 'elementor-youtube-form'); ?>').prop('disabled', false);
                    }
                });
            }
        });
    });
    </script>
    <?php
}

// ==================== MAIN PLUGIN CLASS ====================
final class Elementor_Youtube_Form_Addon {

    const VERSION = '1.5.0';
    const MINIMUM_ELEMENTOR_VERSION = '3.0.0';
    const MINIMUM_PHP_VERSION = '7.0';

    private static $_instance = null;

    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        add_action('init', [$this, 'i18n']);
        add_action('plugins_loaded', [$this, 'init']);
        add_action('wp_ajax_elementor_youtube_form_submit', [$this, 'handle_form_submission']);
        add_action('wp_ajax_nopriv_elementor_youtube_form_submit', [$this, 'handle_form_submission']);
        add_action('wp_ajax_elementor_youtube_form_delete_submission', [$this, 'handle_delete_submission']);
    }

    public function i18n() {
        load_plugin_textdomain('elementor-youtube-form');
    }

    public function init() {
        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_main_plugin']);
            return;
        }

        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Check for required PHP version
        if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
            return;
        }

        // Check for Elementor Pro (needed for forms)
        if (!function_exists('elementor_pro_load_plugin')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_elementor_pro']);
            return;
        }

        // Add Plugin actions
        add_action('elementor/widgets/register', [$this, 'init_widgets']);
        add_action('elementor/frontend/after_register_scripts', [$this, 'register_scripts']);
        add_action('elementor/frontend/after_register_styles', [$this, 'register_styles']);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_styles']);
    }

    public function admin_notice_missing_main_plugin() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'elementor-youtube-form'),
            '<strong>' . esc_html__('Elementor YouTube Form Addon', 'elementor-youtube-form') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-youtube-form') . '</strong>'
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_notice_minimum_elementor_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-youtube-form'),
            '<strong>' . esc_html__('Elementor YouTube Form Addon', 'elementor-youtube-form') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-youtube-form') . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_notice_minimum_php_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-youtube-form'),
            '<strong>' . esc_html__('Elementor YouTube Form Addon', 'elementor-youtube-form') . '</strong>',
            '<strong>' . esc_html__('PHP', 'elementor-youtube-form') . '</strong>',
            self::MINIMUM_PHP_VERSION
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_notice_missing_elementor_pro() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'elementor-youtube-form'),
            '<strong>' . esc_html__('Elementor YouTube Form Addon', 'elementor-youtube-form') . '</strong>',
            '<strong>' . esc_html__('Elementor Pro', 'elementor-youtube-form') . '</strong>'
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function init_widgets($widgets_manager) {
        require_once(__DIR__ . '/includes/widgets/youtube-form.php');
        $widgets_manager->register(new \Elementor_Youtube_Form_Widget());
    }

    public function register_scripts() {
        wp_register_script(
            'elementor-youtube-form',
            plugins_url('/assets/js/frontend.js', __FILE__),
            ['jquery', 'elementor-frontend'],
            self::VERSION,
            true
        );

        wp_localize_script('elementor-youtube-form', 'elementorYoutubeForm', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('elementor_youtube_form_nonce'),
            'loadingText' => __('Processing...', 'elementor-youtube-form'),
            'errorText' => __('An error occurred. Please try again.', 'elementor-youtube-form'),
            'successText' => __('Thank you! Your submission has been received.', 'elementor-youtube-form'),
        ]);
    }

    public function register_styles() {
        wp_register_style(
            'elementor-youtube-form',
            plugins_url('/assets/css/frontendcss.css', __FILE__),
            [],
            self::VERSION
        );

        wp_register_style(
            'elementor-youtube-form-admin',
            plugins_url('/assets/css/admin.css', __FILE__),
            [],
            self::VERSION
        );
    }

    public function enqueue_scripts() {
        wp_enqueue_script('elementor-youtube-form');
    }

    public function enqueue_styles() {
        wp_enqueue_style('elementor-youtube-form');
        
        if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'youtube-form-submissions') {
            wp_enqueue_style('elementor-youtube-form-admin');
        }
    }

    public function handle_form_submission() {
        check_ajax_referer('elementor_youtube_form_nonce', 'nonce');

        if (!isset($_POST['form_data']) || !is_array($_POST['form_data'])) {
            wp_send_json_error(['message' => __('Invalid form data.', 'elementor-youtube-form')]);
            wp_die();
        }

        try {
            $form_data = $_POST['form_data'];
            $post_id = isset($form_data['post_id']) ? intval($form_data['post_id']) : 0;
            $widget_id = isset($form_data['widget_id']) ? sanitize_text_field($form_data['widget_id']) : '';
            
            unset($form_data['post_id']);
            unset($form_data['widget_id']);
            
            $video_id = '';
            if ($post_id && $widget_id) {
                $document = \Elementor\Plugin::$instance->documents->get($post_id);
                if ($document) {
                    $elements = $document->get_elements_data();
                    $widget_data = $this->find_widget_data($elements, $widget_id);
                    if ($widget_data && isset($widget_data['settings']['youtube_url']['url'])) {
                        $video_id = $this->extract_youtube_id($widget_data['settings']['youtube_url']['url']);
                    }
                }
            }

            $sanitized_data = [];
            foreach ($form_data as $key => $value) {
                if (is_array($value)) {
                    $sanitized_data[sanitize_text_field($key)] = array_map('sanitize_text_field', $value);
                } else {
                    $sanitized_data[sanitize_text_field($key)] = sanitize_text_field($value);
                }
            }

            $errors = [];
            foreach ($sanitized_data as $field => $value) {
                if (strpos($field, 'required_') === 0 && empty($value)) {
                    $field_name = str_replace(['required_', '_'], ['', ' '], $field);
                    $errors[$field] = sprintf(__('%s is required', 'elementor-youtube-form'), ucfirst($field_name));
                }
            }

            if (!empty($errors)) {
                wp_send_json_error([
                    'message' => __('Please fix the following errors:', 'elementor-youtube-form'),
                    'errors' => $errors
                ]);
                wp_die();
            }

            global $wpdb;
            $table_name = $wpdb->prefix . 'elementor_youtube_form_submissions';
            
            $inserted = $wpdb->insert(
                $table_name,
                [
                    'post_id' => $post_id,
                    'widget_id' => $widget_id,
                    'video_id' => $video_id,
                    'form_data' => maybe_serialize($sanitized_data),
                    'submitted_at' => current_time('mysql'),
                ],
                [
                    '%d',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                ]
            );

            $submission_id = $wpdb->insert_id;
            $webhook_response = '';
            $webhook_status = 'not_sent';

            if ($post_id && $widget_id) {
                $widget_settings = $this->get_widget_settings($post_id, $widget_id);
                if ($widget_settings && isset($widget_settings['webhook_enabled']) && $widget_settings['webhook_enabled'] === 'yes') {
                    $webhook_url = isset($widget_settings['webhook_url']['url']) ? $widget_settings['webhook_url']['url'] : '';
                    $webhook_method = isset($widget_settings['webhook_method']) ? $widget_settings['webhook_method'] : 'POST';

                    if (!empty($webhook_url)) {
                        $payload = [
                            'event' => 'youtube_form_submission',
                            'data' => [
                                'form_fields' => $sanitized_data,
                                'metadata' => [
                                    'video_id' => $video_id,
                                    'post_id' => $post_id,
                                    'widget_id' => $widget_id,
                                    'submitted_at' => current_time('mysql'),
                                ]
                            ]
                        ];

                        $args = [
                            'method' => $webhook_method,
                            'headers' => [
                                'Content-Type' => 'application/json',
                                'Accept' => 'application/json'
                            ],
                            'body' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                            'timeout' => 15,
                            'data_format' => 'body'
                        ];

                        $response = wp_remote_request($webhook_url, $args);
                        
                        if (is_wp_error($response)) {
                            $webhook_response = $response->get_error_message();
                            $webhook_status = 'failed';
                        } else {
                            $response_code = wp_remote_retrieve_response_code($response);
                            $webhook_response = wp_remote_retrieve_body($response);
                            $webhook_status = ($response_code >= 200 && $response_code < 300) ? 'success' : 'failed';
                        }

                        if ($submission_id) {
                            $wpdb->update(
                                $table_name,
                                [
                                    'webhook_response' => $webhook_response,
                                    'webhook_status' => $webhook_status
                                ],
                                ['id' => $submission_id],
                                ['%s', '%s'],
                                ['%d']
                            );
                        }
                    }
                }
            }

            if ($inserted) {
                wp_send_json_success([
                    'message' => __('Thank you! Your submission has been received.', 'elementor-youtube-form'),
                    'submission_id' => $submission_id,
                    'webhook_status' => $webhook_status
                ]);
            } else {
                wp_send_json_error(['message' => __('Submission failed. Please try again.', 'elementor-youtube-form')]);
            }
            
        } catch (Exception $e) {
            error_log('YouTube Form Addon error: ' . $e->getMessage());
            wp_send_json_error(['message' => __('An error occurred. Please try again.', 'elementor-youtube-form')]);
        }
        
        wp_die();
    }

    private function get_widget_settings($post_id, $widget_id) {
        $document = \Elementor\Plugin::$instance->documents->get($post_id);
        if (!$document) {
            return false;
        }

        $elements = $document->get_elements_data();
        $widget_data = $this->find_widget_data($elements, $widget_id);
        return $widget_data ? $widget_data['settings'] : false;
    }

    private function find_widget_data($elements, $widget_id) {
        foreach ($elements as $element) {
            if (isset($element['id']) && $element['id'] === $widget_id) {
                return $element;
            }
            
            if (!empty($element['elements'])) {
                $found = $this->find_widget_data($element['elements'], $widget_id);
                if ($found) {
                    return $found;
                }
            }
        }
        return false;
    }

    private function extract_youtube_id($url) {
        $pattern = '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i';
        preg_match($pattern, $url, $matches);
        return isset($matches[1]) ? $matches[1] : false;
    }

    public function handle_delete_submission() {
        check_ajax_referer('elementor_youtube_form_delete_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'elementor-youtube-form')]);
            wp_die();
        }

        if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
            wp_send_json_error(['message' => __('Invalid submission ID.', 'elementor-youtube-form')]);
            wp_die();
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'elementor_youtube_form_submissions';
        $deleted = $wpdb->delete($table_name, ['id' => intval($_POST['id'])], ['%d']);

        if ($deleted) {
            wp_send_json_success(['message' => __('Submission deleted successfully.', 'elementor-youtube-form')]);
        } else {
            wp_send_json_error(['message' => __('Failed to delete submission.', 'elementor-youtube-form')]);
        }
        
        wp_die();
    }
}

Elementor_Youtube_Form_Addon::instance();
