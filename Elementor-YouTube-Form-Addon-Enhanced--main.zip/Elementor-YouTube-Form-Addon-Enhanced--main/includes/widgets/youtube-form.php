<?php
class Elementor_Youtube_Form_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'youtube_form';
    }

    public function get_title() {
        return __('YouTube Video with Form', 'elementor-youtube-form');
    }

    public function get_icon() {
        return 'eicon-youtube';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'elementor-youtube-form'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'youtube_url',
            [
                'label' => __('YouTube URL', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://youtube.com/watch?v=EXAMPLE', 'elementor-youtube-form'),
                'show_external' => false,
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'video_title',
            [
                'label' => __('Video Title', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Featured Video', 'elementor-youtube-form'),
                'placeholder' => __('Enter video title', 'elementor-youtube-form'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'elementor-youtube-form'),
                'label_off' => __('No', 'elementor-youtube-form'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'mute_on_autoplay',
            [
                'label' => __('Mute on Autoplay', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'elementor-youtube-form'),
                'label_off' => __('No', 'elementor-youtube-form'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'pause_time',
            [
                'label' => __('Pause Time (seconds)', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 3600,
                'step' => 1,
                'default' => 30,
                'description' => __('Video will pause at this time to show the form', 'elementor-youtube-form'),
            ]
        );

        // Form fields repeater
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'field_type',
            [
                'label' => __('Field Type', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'text' => __('Text', 'elementor-youtube-form'),
                    'email' => __('Email', 'elementor-youtube-form'),
                    'textarea' => __('Textarea', 'elementor-youtube-form'),
                    'select' => __('Select', 'elementor-youtube-form'),
                ],
                'default' => 'text',
            ]
        );

        $repeater->add_control(
            'field_name',
            [
                'label' => __('Field Name', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'description' => __('Used for form processing', 'elementor-youtube-form'),
            ]
        );

        $repeater->add_control(
            'field_label',
            [
                'label' => __('Label', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $repeater->add_control(
            'placeholder',
            [
                'label' => __('Placeholder', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'condition' => [
                    'field_type!' => ['select'],
                ],
            ]
        );

        $repeater->add_control(
            'options',
            [
                'label' => __('Options', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => '',
                'description' => __('One option per line', 'elementor-youtube-form'),
                'condition' => [
                    'field_type' => 'select',
                ],
            ]
        );

        $repeater->add_control(
            'required',
            [
                'label' => __('Required', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'elementor-youtube-form'),
                'label_off' => __('No', 'elementor-youtube-form'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'form_fields',
            [
                'label' => __('Form Fields', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ field_label }}} ({{{ field_type }}})',
                'default' => [
                    [
                        'field_type' => 'text',
                        'field_name' => 'name',
                        'field_label' => __('Name', 'elementor-youtube-form'),
                        'placeholder' => __('Your name', 'elementor-youtube-form'),
                        'required' => 'yes',
                    ],
                    [
                        'field_type' => 'email',
                        'field_name' => 'email',
                        'field_label' => __('Email', 'elementor-youtube-form'),
                        'placeholder' => __('Your email', 'elementor-youtube-form'),
                        'required' => 'yes',
                    ],
                ],
            ]
        );

        $this->add_control(
            'submit_button_text',
            [
                'label' => __('Submit Button Text', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Submit', 'elementor-youtube-form'),
            ]
        );

        $this->add_control(
            'success_message',
            [
                'label' => __('Success Message', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Thank you! Your information has been submitted.', 'elementor-youtube-form'),
            ]
        );

        $this->end_controls_section();

        // Webhook Section
        $this->start_controls_section(
            'webhook_section',
            [
                'label' => __('Webhook Integration', 'elementor-youtube-form'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'webhook_enabled',
            [
                'label' => __('Enable Webhook?', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'elementor-youtube-form'),
                'label_off' => __('No', 'elementor-youtube-form'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'webhook_url',
            [
                'label' => __('Webhook URL', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-webhook-url.com', 'elementor-youtube-form'),
                'condition' => [
                    'webhook_enabled' => 'yes',
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'webhook_method',
            [
                'label' => __('HTTP Method', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'POST',
                'options' => [
                    'POST' => __('POST', 'elementor-youtube-form'),
                    'GET' => __('GET', 'elementor-youtube-form'),
                    'PUT' => __('PUT', 'elementor-youtube-form'),
                ],
                'condition' => [
                    'webhook_enabled' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Video Style', 'elementor-youtube-form'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'overlay_color',
            [
                'label' => __('Overlay Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .youtube-video-overlay' => 'background-color: {{VALUE}};',
                ],
                'default' => 'rgba(255, 255, 255, 0)',
            ]
        );

        $this->add_control(
            'overlay_opacity',
            [
                'label' => __('Overlay Opacity', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0,
                        'step' => 0.01,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .youtube-video-overlay' => 'opacity: {{SIZE}};',
                ],
                'default' => [
                    'size' => '1',
                ],
            ]
        );

        $this->add_control(
            'title_bar_color',
            [
                'label' => __('Title Bar Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-title-bar' => 'background-color: {{VALUE}};',
                ],
                'default' => 'rgba(255, 255, 255, 0)',
            ]
        );

        $this->add_control(
            'title_text_color',
            [
                'label' => __('Title Text Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-title' => 'color: {{VALUE}};',
                ],
                'default' => '#fff',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .video-title',
            ]
        );

        $this->end_controls_section();

        // Button Style
        $this->start_controls_section(
            'button_style',
            [
                'label' => __('Submit Button', 'elementor-youtube-form'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .youtube-form-popup .submit-btn',
            ]
        );

        $this->start_controls_tabs('button_tabs');

        $this->start_controls_tab(
            'button_normal',
            [
                'label' => __('Normal', 'elementor-youtube-form'),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .youtube-form-popup .submit-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .youtube-form-popup .submit-btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover',
            [
                'label' => __('Hover', 'elementor-youtube-form'),
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label' => __('Text Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .youtube-form-popup .submit-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_hover_color',
            [
                'label' => __('Background Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .youtube-form-popup .submit-btn:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __('Border Color', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .youtube-form-popup .submit-btn:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .youtube-form-popup .submit-btn',
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .youtube-form-popup .submit-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .youtube-form-popup .submit-btn',
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Padding', 'elementor-youtube-form'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .youtube-form-popup .submit-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

protected function render() {
    $settings = $this->get_settings_for_display();

    if (empty($settings['youtube_url']['url'])) {
        echo $this->show_error_message(__('Please enter a YouTube URL', 'elementor-youtube-form'));
        return;
    }

    $video_id = $this->extract_youtube_id($settings['youtube_url']['url']);
    if (!$video_id) {
        echo $this->show_error_message(__('Invalid YouTube URL', 'elementor-youtube-form'));
        return;
    }

    // Build YouTube URL parameters
    $url_params = 'enablejsapi=1&rel=0&modestbranding=1&disablekb=1&showinfo=0';
    
    if ($settings['autoplay'] === 'yes') {
        $url_params .= '&autoplay=1';
        if ($settings['mute_on_autoplay'] === 'yes') {
            $url_params .= '&mute=1';
        }
    }

    $this->add_render_attribute('wrapper', [
        'class' => 'youtube-form-container',
        'data-video-id' => $video_id,
        'data-pause-time' => $settings['pause_time'],
        'data-widget-id' => $this->get_id(),
        'data-video-title' => esc_attr($settings['video_title']),
        'data-autoplay' => $settings['autoplay'],
        'data-mute-on-autoplay' => $settings['mute_on_autoplay'],
    ]);
    ?>

    <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
        <div class="youtube-video-wrapper">
            <iframe id="youtube-video-<?php echo esc_attr($this->get_id()); ?>"
                src="https://www.youtube.com/embed/<?php echo esc_attr($video_id); ?>?<?php echo $url_params; ?>"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
            <?php if ($settings['autoplay'] === 'yes') : ?>
                <div class="youtube-video-overlay autoplay-overlay" style="z-index: 5;"></div>
            <?php else : ?>
                <div class="youtube-video-overlay"></div>
            <?php endif; ?>
        </div>

        <div id="form-popup-<?php echo esc_attr($this->get_id()); ?>" class="youtube-form-popup" style="display:none;">
            <div class="popup-overlay"></div>
            <div class="popup-content">
                <span class="close-popup">&times;</span>
                <div class="popup-body">
                    <?php $this->render_form($settings); ?>
                </div>
            </div>
        </div>
    </div>
    <?php
}

    protected function render_form($settings) {
        ?>
        <form class="elementor-youtube-form" id="youtube-form-<?php echo esc_attr($this->get_id()); ?>">
            <input type="hidden" name="post_id" value="<?php echo get_the_ID(); ?>">
            <input type="hidden" name="widget_id" value="<?php echo $this->get_id(); ?>">

            <?php foreach ($settings['form_fields'] as $index => $item): ?>
                <div class="form-group">
                    <?php if (!empty($item['field_label'])): ?>
                        <label for="field-<?php echo $index; ?>" class="form-label">
                            <?php echo esc_html($item['field_label']); ?>
                            <?php if ($item['required'] === 'yes'): ?>
                                <span class="required">*</span>
                            <?php endif; ?>
                        </label>
                    <?php endif; ?>

                    <?php switch ($item['field_type']):
                        case 'text':
                        case 'email': ?>
                            <input type="<?php echo esc_attr($item['field_type']); ?>"
                                id="field-<?php echo $index; ?>"
                                name="<?php echo esc_attr($item['field_name']); ?>"
                                class="form-control"
                                placeholder="<?php echo esc_attr($item['placeholder']); ?>"
                                <?php if ($item['required'] === 'yes') echo 'required'; ?>>
                            <?php break;
                        case 'textarea': ?>
                            <textarea id="field-<?php echo $index; ?>"
                                name="<?php echo esc_attr($item['field_name']); ?>"
                                class="form-control"
                                placeholder="<?php echo esc_attr($item['placeholder']); ?>"
                                <?php if ($item['required'] === 'yes') echo 'required'; ?>></textarea>
                            <?php break;
                        case 'select': ?>
                            <select id="field-<?php echo $index; ?>"
                                name="<?php echo esc_attr($item['field_name']); ?>"
                                class="form-control"
                                <?php if ($item['required'] === 'yes') echo 'required'; ?>>
                                <?php if (!empty($item['placeholder'])): ?>
                                    <option value=""><?php echo esc_html($item['placeholder']); ?></option>
                                <?php endif; ?>
                                <?php if (!empty($item['options'])):
                                    $options = explode("\n", $item['options']);
                                    foreach ($options as $option):
                                        $option = trim($option);
                                        if (!empty($option)): ?>
                                            <option value="<?php echo esc_attr($option); ?>"><?php echo esc_html($option); ?></option>
                                        <?php endif;
                                    endforeach;
                                endif; ?>
                            </select>
                            <?php break;
                    endswitch; ?>
                </div>
            <?php endforeach; ?>

            <div class="form-group">
                <button type="submit" class="submit-btn">
                    <?php echo esc_html($settings['submit_button_text']); ?>
                </button>
            </div>
        </form>
        <div class="form-message" style="display:none;"></div>
        <?php
    }

    private function show_error_message($message) {
        return '<div class="elementor-alert elementor-alert-danger">' . esc_html($message) . '</div>';
    }

    private function extract_youtube_id($url) {
        $pattern = '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i';
        preg_match($pattern, $url, $matches);
        return isset($matches[1]) ? $matches[1] : false;
    }
}